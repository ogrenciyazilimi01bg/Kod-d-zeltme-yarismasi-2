﻿using CourseApp.EntityLayer.Entity;

namespace CourseApp.DataAccessLayer.Abstract;

public interface IStudentRepository:IGenericRepository<Student>
{
}
