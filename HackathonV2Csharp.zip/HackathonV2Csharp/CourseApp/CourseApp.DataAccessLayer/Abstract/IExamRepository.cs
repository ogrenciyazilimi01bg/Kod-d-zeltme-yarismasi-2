﻿using CourseApp.EntityLayer.Entity;

namespace CourseApp.DataAccessLayer.Abstract;

public interface IExamRepository:IGenericRepository<Exam>
{
}
