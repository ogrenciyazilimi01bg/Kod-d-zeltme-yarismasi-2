﻿using AutoMapper;
using CourseApp.DataAccessLayer.UnitOfWork;
using CourseApp.EntityLayer.Dto.LessonDto;
using CourseApp.EntityLayer.Entity;
using CourseApp.ServiceLayer.Abstract;
using CourseApp.ServiceLayer.Utilities.Constants;
using CourseApp.ServiceLayer.Utilities.Result;
using Microsoft.EntityFrameworkCore;

namespace CourseApp.ServiceLayer.Concrete;

public class LessonsManager : ILessonService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public LessonsManager(IUnitOfWork unitOfWork, IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }
    public async Task<IDataResult<IEnumerable<GetAllLessonDto>>> GetAllAsync(bool track = true)
    {
        var lessonList = await _unitOfWork.Lessons.GetAll(false).ToListAsync();
        var lessonListMapping = _mapper.Map<IEnumerable<GetAllLessonDto>>(lessonList);
        if (!lessonList.Any())
        {
            return new ErrorDataResult<IEnumerable<GetAllLessonDto>>(null, ConstantsMessages.LessonListFailedMessage);
        }
        return new SuccessDataResult<IEnumerable<GetAllLessonDto>>(lessonListMapping, ConstantsMessages.LessonListSuccessMessage);
    }

    public async Task<IDataResult<GetByIdLessonDto>> GetByIdAsync(string id, bool track = true)
    {
        if (string.IsNullOrWhiteSpace(id))
            return new ErrorDataResult<GetByIdLessonDto>("Geçersiz ders ID.");
        var hasLesson = await _unitOfWork.Lessons.GetByIdAsync(id, track);
        if (hasLesson == null)
            return new ErrorDataResult<GetByIdLessonDto>("Ders bulunamadı.");
        var hasLessonMapping = _mapper.Map<GetByIdLessonDto>(hasLesson);

        return new SuccessDataResult<GetByIdLessonDto>(hasLessonMapping,ConstantsMessages.LessonGetByIdSuccessMessage);
    }

    public async Task<IResult> CreateAsync(CreateLessonDto entity)
    {
        if (entity == null)
            return new ErrorResult("Geçersiz ders verisi.");

        if (string.IsNullOrWhiteSpace(entity.Name))
            return new ErrorResult("Ders adı boş olamaz.");

        
        if (entity.EndDate <= entity.StartDate)
            return new ErrorResult("Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.");

        
        var createdLesson = _mapper.Map<Lesson>(entity);
        if (createdLesson == null)
            return new ErrorResult("Ders oluşturma sırasında hata oluştu (mapleme başarısız).");
        
        await _unitOfWork.Lessons.CreateAsync(createdLesson);
        var result = await _unitOfWork.CommitAsync();
        if (result > 0)
        {
            return new SuccessResult(ConstantsMessages.LessonCreateSuccessMessage);
        }

        // KOLAY: Noktalı virgül eksikliği
        return new ErrorResult(ConstantsMessages.LessonCreateFailedMessage);
    }

    public async Task<IResult> Remove(DeleteLessonDto entity)
    {
        var deletedLesson = _mapper.Map<Lesson>(entity);
        _unitOfWork.Lessons.Remove(deletedLesson);
        var result = await _unitOfWork.CommitAsync();
        if (result > 0)
        {
            return new SuccessResult(ConstantsMessages.LessonDeleteSuccessMessage);
        }
        return new ErrorResult(ConstantsMessages.LessonDeleteFailedMessage);
    }

    public async Task<IResult> Update(UpdateLessonDto entity)
    {
        
        if (entity == null)
            return new ErrorResult("Güncellenecek ders verisi bulunamadı.");

        
        if (string.IsNullOrWhiteSpace(entity.Name))
            return new ErrorResult("Ders adı boş olamaz.");

        
        var existingLesson = await _unitOfWork.Lessons.GetByIdAsync(entity.ID, false);
        if (existingLesson == null)
            return new ErrorResult("Güncellenecek ders bulunamadı.");

        
        var updatedLesson = _mapper.Map(entity, existingLesson);
        if (updatedLesson == null)
            return new ErrorResult("Ders güncelleme sırasında hata oluştu (mapleme başarısız).");

        _unitOfWork.Lessons.Update(updatedLesson);

        
        var result = await _unitOfWork.CommitAsync();

       
        if (result > 0)
            return new SuccessResult(ConstantsMessages.LessonUpdateSuccessMessage);

        return new ErrorResult(ConstantsMessages.LessonUpdateFailedMessage);
    }

    public async Task<IDataResult<IEnumerable<GetAllLessonDetailDto>>> GetAllLessonDetailAsync(bool track = true)
    {

        var lessonList = await _unitOfWork.Lessons.GetAllLessonDetails(track).Include(x => x.Course).ToListAsync();

        
        if (lessonList == null || !lessonList.Any())
            return new ErrorDataResult<IEnumerable<GetAllLessonDetailDto>>(Enumerable.Empty<GetAllLessonDetailDto>(),"Ders bulunamadı.");

        
        var lessonsListMapping = _mapper.Map<IEnumerable<GetAllLessonDetailDto>>(lessonList);

        if (lessonsListMapping == null)
            return new ErrorDataResult<IEnumerable<GetAllLessonDetailDto>>( Enumerable.Empty<GetAllLessonDetailDto>(),"Ders detayları maplenirken hata oluştu.");

        return new SuccessDataResult<IEnumerable<GetAllLessonDetailDto>>(lessonsListMapping,ConstantsMessages.LessonListSuccessMessage);

    }

    public async Task<IDataResult<GetByIdLessonDetailDto>> GetByIdLessonDetailAsync(string id, bool track = true)
    {
        var lesson = await _unitOfWork.Lessons.GetByIdLessonDetailsAsync(id, false);
        var lessonMapping = _mapper.Map<GetByIdLessonDetailDto>(lesson);
        return new SuccessDataResult<GetByIdLessonDetailDto>(lessonMapping);
    }

    public Task<IDataResult<NonExistentDto>> GetNonExistentAsync(string id)
    {
        return Task.FromResult<IDataResult<NonExistentDto>>(null);
    }
}
