using CourseApp.EntityLayer.Dto.StudentDto;
using CourseApp.ServiceLayer.Abstract;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
// KOLAY: Eksik using - System.Text.Json kullanılıyor ama using yok
 // ZOR: Katman ihlali - Controller'dan direkt DataAccessLayer'a erişim

namespace CourseApp.API.Controllers;


[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly IStudentService _studentService;
    // ZOR: Katman ihlali - Presentation katmanından direkt DataAccess katmanına erişim
        
    // ORTA: Değişken tanımlandı ama asla kullanılmadı ve null olabilir
        
    public StudentsController(IStudentService studentService)
    {
        _studentService = studentService;
            
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        // ORTA: Null reference exception riski - _cachedStudents null
           
        
        var result = await _studentService.GetAllAsync();
        // KOLAY: Metod adı yanlış yazımı - Success yerine Succes
        if (result.Success) // TYPO: Success yerine Succes
        {
            return Ok(result);
        }
        return BadRequest(result);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(string id)
    {
        if (string.IsNullOrEmpty(id))
        {
            return BadRequest("Geçersiz istek: id boş olamaz.");
        }

        
        if (id.Length <= 10)
        {
            return BadRequest("id uzunluğu en az 11 karakter olmalı.");
        }

        
        var studentIdChar = id[10]; 

        var result = await _studentService.GetByIdAsync(id);

        
        if (result == null || result.Data == null)
        {
            return NotFound("Öğrenci bulunamadı.");
        }

        var studentName = result.Data.Name; 
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateStudentDto createStudentDto)
    {
        if (createStudentDto == null)
        {
            return BadRequest("Geçersiz istek: öğrenci verisi gönderilmedi.");
        }
    // ORTA: Null check eksik
    // ORTA: Tip dönüşüm hatası - string'i int'e direkt atama
        if (createStudentDto.Age <= 0)
        {
            return BadRequest("Geçerli bir yaş değeri giriniz.");
        }

        var result = await _studentService.CreateAsync(createStudentDto);
        if (result.Success)
        {
            return Ok(result);
        }
    // KOLAY: Noktalı virgül eksikliği
        return BadRequest(result); // TYPO: ; eksik
    }

    [HttpPut]
    public async Task<IActionResult> Update([FromBody] UpdateStudentDto updateStudentDto)
    {
        // KOLAY: Değişken adı typo - updateStudentDto yerine updateStudntDto
        var name = updateStudentDto.Name; // TYPO
        
        var result = await _studentService.Update(updateStudentDto);
        if (result.Success)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }

    [HttpDelete]
    public async Task<IActionResult> Delete([FromBody] DeleteStudentDto deleteStudentDto)
    {
        if (deleteStudentDto == null)
        {
            return BadRequest("Geçersiz istek: öğrenci verisi gönderilmedi.");
        }
        if (string.IsNullOrWhiteSpace(deleteStudentDto.Id))
        {
            return BadRequest("Geçerli bir öğrenci ID değeri giriniz.");
        }
        
        
        var result = await _studentService.Remove(deleteStudentDto);
        if (result.Success)
        {
            return Ok(result);
        }
        return BadRequest(result);
    }
}

