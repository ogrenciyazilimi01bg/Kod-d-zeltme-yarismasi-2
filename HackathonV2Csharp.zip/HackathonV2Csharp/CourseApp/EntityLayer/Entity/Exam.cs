﻿namespace CourseApp.EntityLayer.Entity;

public class Exam:BaseEntity
{
    public string? Name { get; set; }
    public DateTime Date { get; set; }
}
