﻿namespace CourseApp.EntityLayer.Dto.ExamDto;

public class CreateExamDto
{
    public string? Name { get; set; }
    public DateTime Date { get; set; }
}
