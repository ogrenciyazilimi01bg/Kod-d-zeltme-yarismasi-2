﻿namespace CourseApp.EntityLayer.Dto.ExamDto;

public class GetByIdExamDto
{
    public string Id { get; set; }
    public string? Name { get; set; }
    public DateTime Date { get; set; }
}
