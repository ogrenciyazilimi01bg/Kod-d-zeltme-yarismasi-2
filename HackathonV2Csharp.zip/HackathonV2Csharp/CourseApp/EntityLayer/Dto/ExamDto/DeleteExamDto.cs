﻿namespace CourseApp.EntityLayer.Dto.ExamDto;

public class DeleteExamDto
{
    public string Id { get; set; }
    public string? Name { get; set; }
    public DateTime Date { get; set; }
}
